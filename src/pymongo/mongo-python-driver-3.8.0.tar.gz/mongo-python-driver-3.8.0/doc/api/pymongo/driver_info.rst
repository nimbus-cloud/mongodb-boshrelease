:mod:`driver_info`
==================

.. automodule:: pymongo.driver_info

   .. autoclass:: pymongo.driver_info.DriverInfo(name=None, version=None, platform=None)
